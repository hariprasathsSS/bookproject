from pydantic import BaseModel
from datetime import datetime
from app.models import Idname


class Book(BaseModel):
    created_at:datetime
    updated_at:datetime
    name: str
    description:str
    author: Idname
    is_published: bool
    publisher: Idname
    category: Idname
    average_rating: float
    total_reviews:int
