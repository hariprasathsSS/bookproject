from pydantic import BaseModel
from datetime import datetime
from app.models import Idname
class Author(BaseModel):
    created_at:datetime
    updated_at:datetime
    name:str
    latest_books:list[dict]
    age:int
    gender:str
    awards:list[str]
    total_published:int
    average_rating:float
