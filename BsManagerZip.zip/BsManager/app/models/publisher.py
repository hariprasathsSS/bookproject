from pydantic import BaseModel
from app.models import Idname

class Publisher(BaseModel):
    name:str
    location:str
    books:list[Idname]