from pydantic import BaseModel
from datetime import datetime
from app.models import Idname


class User(BaseModel):
    created_at:datetime
    updated_at:datetime
    name:str
    email:str
    gender:str
    age:int
    phone_number:str
    favorite_books:list[Idname]
    total_reviews:int