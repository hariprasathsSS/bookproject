from pydantic import BaseModel
from datetime import datetime
from app.models import Idname

class Comments(BaseModel):
    id:str
    user:str
    content:str


class Review_details(BaseModel):
    likes:int
    comments:list[Comments]


class Review(BaseModel):
    created_at:datetime
    updated_at:datetime
    book_id : Idname
    content : str
    created_by:Idname
    rating : int
    review_details:Review_details