from pydantic import BaseModel

class Idname(BaseModel):
    id:str
    name:str