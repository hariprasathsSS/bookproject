from fastapi import APIRouter,HTTPException,Depends,status
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.database import get_database
from app.schemas.authors import AuthorCreate,AuthorResponse,AuthorUpdate
from app.services.authors import AuthorService
router=APIRouter(prefix="",tags=['Author'])

def AuthService(db:AsyncIOMotorDatabase = Depends(get_database)):
    return AuthorService(db)

@router.post("/")
async def createAuthor(addAuthor:AuthorCreate,db:AuthorService=Depends(AuthService)):

    return await db.createAuthor(addAuthor)

@router.get("/",response_model=list[AuthorResponse])
async def getAllAuthor(db:AuthorService=Depends(AuthService)):
    
    return await db.getAllAuthor()

@router.get("/{auth_id}",response_model=AuthorResponse)
async def getAuthor(auth_id:str,db:AuthorService=Depends(AuthService)):
    
    return await db.getAuthor(auth_id)

@router.put("/{auth_id}",response_model=AuthorResponse)
async def updateAuthor(auth_id:str,uAuthor:AuthorUpdate,db:AuthorService=Depends(AuthService)):

    return await db.updateAuthor(auth_id,uAuthor)

@router.delete("/{auth_id}")
async def deleteAuthor(auth_id:str,db:AuthorService=Depends(AuthService)):

    return await db.deleteAuthor(auth_id=auth_id)


