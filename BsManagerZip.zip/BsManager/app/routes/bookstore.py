from fastapi import APIRouter,Depends,status
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.database import get_database
from app.services.bookstore import BookStoreService
from app.schemas.bookstore import CreateBookStore,ResponseBookStore,UpdateBookStore

bookstore_router = APIRouter(prefix="/bookstore",tags=['Bookstore'])

def bookStoreService(db:AsyncIOMotorDatabase = Depends(get_database)):
    return BookStoreService(db)

@bookstore_router.post("/",status_code=status.HTTP_201_CREATED)
async def createBookstore(newBookStore:CreateBookStore ,service : BookStoreService=Depends(bookStoreService)):
    return await service.CreateBookStore(newBookStore)

@bookstore_router.get("/{bookstore_id}",response_model=ResponseBookStore)
async def getBookstore(bookstore_id:str ,service : BookStoreService=Depends(bookStoreService)):
    return await service.getBookstoreDetails(bookstore_id)

@bookstore_router.get("/location/{bookstore_location}",response_model=list[ResponseBookStore])
async def getBookstoreLocation(bookstore_location:str ,service : BookStoreService=Depends(bookStoreService)):
    return await service.getBookStoreByLocation(bookstore_location)

@bookstore_router.get("/",response_model=list[ResponseBookStore])
async def getALlBookstore(service : BookStoreService=Depends(bookStoreService)):
    return await service.getAllBookStore()

@bookstore_router.delete("/",status_code=status.HTTP_204_NO_CONTENT)
async def deleteBookstore(bookstore_id:str ,service : BookStoreService=Depends(bookStoreService)):
    await service.deleteBookstore(bookstore_id)

@bookstore_router.post("/{bookstore_id}/books/{book_id}",status_code=status.HTTP_201_CREATED)
async def addBookToBookStore(newBookStore:CreateBookStore ,service : BookStoreService=Depends(bookStoreService)):
    return await service.addBookToBookStore(newBookStore)