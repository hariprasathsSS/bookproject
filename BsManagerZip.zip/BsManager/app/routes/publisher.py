from fastapi import Depends,HTTPException,APIRouter,status
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.schemas.publisher import PublisherCreate,PublisherResponse,PublisherUpdate
from app.models.publisher import Publisher
from app.database import get_database
from app.services.publisher import PublisherService

publisher_router = APIRouter(prefix="/Publisher",tags=['Publisher'])

def PubService(db:AsyncIOMotorDatabase = Depends(get_database)):
    return PublisherService(db)

@publisher_router.post("/",status_code=status.HTTP_201_CREATED)
async def addPublisher(publisherData:PublisherCreate,db : PublisherService = Depends(PubService)):

    return await db.addPublisher(publisherData)

@publisher_router.get("/",response_model=list[PublisherResponse])
async def getAllPublisher(db : PublisherService = Depends(PubService)):

    return await db.getAllPublishers()

@publisher_router.get("/{pub_id}",response_model=PublisherResponse)
async def getPublisher(pub_id:str,db : PublisherService = Depends(PubService)):

    return await db.getPublisher(pub_id=pub_id)

@publisher_router.put("/{pub_id}")
async def updatePublisher(pub_id:str,Upublisher:PublisherUpdate,db : PublisherService = Depends(PubService)):

    return await db.updatePublisher(pub_id,Upublisher)

@publisher_router.delete("/{pub_id}",status_code=status.HTTP_204_NO_CONTENT)
async def deletePublisher(pub_id:str,db : PublisherService = Depends(PubService)):
    return await db.deletePublisher(pub_id)


