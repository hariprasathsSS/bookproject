from pydantic import BaseModel, Field
from typing import Optional
from app.schemas import Idname
from datetime import datetime

class Comments(BaseModel):
    id:str = Field(...,examples=["8888ioweasf"])
    user:str = Field(...,examples=["John"])
    content:str=Field(...,examples=["Very Good review"])


class ReviewDetails(BaseModel):
    likes:int
    comments:list[Comments]


class ReviewCreate(BaseModel):
    # created_at:datetime
    # updated_at:datetime
    book_id: Idname
    created_by: Idname
    content: str = Field(..., examples=["Great Book"])
    rating: int = Field(..., ge=1, le=5, examples=[4])


class ReviewUpdate(BaseModel):
    # created_at:datetime
    # updated_at:datetime
    book_id : Optional[Idname]=None
    content : Optional[str]=Field(None,examples=["Great Book"])
    rating : Optional[int] =Field(None,examples=[7])

class ReviewResponse(BaseModel):
    id:str = Field(...,examples=["887878778terwe7877r"])
    created_at:datetime
    updated_at:datetime
    book_id : Idname
    rating : int =Field(...,examples=[7])
    content : str=Field(...,examples=["Great Book"])
    created_by:Idname
    review_details:ReviewDetails

