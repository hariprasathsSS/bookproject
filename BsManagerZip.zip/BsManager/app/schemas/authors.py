from pydantic import BaseModel,Field
from typing import Optional
from app.schemas import Idname
from datetime import datetime

class AuthorCreate(BaseModel):
    # created_at:datetime
    # updated_at:datetime
    name:str=Field(...,examples=["James"])
    latest_books:list[Idname]
    age:int=Field(...,examples=[25])
    gender:str=Field(...,examples=["Male"])
    awards:list[str]=Field(...,examples=[" Best writer of the decade - 2018 "])
    total_published:int=Field(...,examples=[4])
    average_rating:float=Field(...,examples=[4.2])

class AuthorUpdate(BaseModel):
    # created_at:datetime
    # updated_at:datetime
    name:Optional[str]=Field(None,examples=["James"])
    latest_books:Optional[list[Idname]]
    age:Optional[int]=Field(None,examples=[25])
    gender:Optional[str]=Field(None,examples=["Male"])
    awards:Optional[list[str]]=Field(None,examples=[" Best writer of the decade - 2018 "])
    total_published:Optional[int]=Field(None,examples=[4])
    average_rating:Optional[float]=Field(None,examples=[4.2])


class AuthorResponse(BaseModel):
    id:str=Field(...,examples=["1616165165161dfd2f1d"])
    created_at:datetime=Field(...,examples=["2024-07-01T15:40:30.960000"])
    updated_at:datetime
    name:str=Field(...,examples=["James"])
    latest_books:list[Idname]
    age:int=Field(...,examples=[25])
    gender:str=Field(...,examples=["Male"])
    awards:list[str]=Field(...,examples=[" Best writer of the decade - 2018 "])
    total_published:int=Field(...,examples=[4])
    average_rating:float=Field(...,examples=[4.2])