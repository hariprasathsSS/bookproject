from pydantic import BaseModel,Field

class Idname(BaseModel):
    id:str=Field(...,examples=["511f51351t3r5tr131"])
    name:str=Field(...,examples=["joe"])