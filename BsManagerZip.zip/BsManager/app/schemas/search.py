from pydantic import BaseModel,Field

class SearchBook(BaseModel):
    name:str = None
    author:str = None
    category:str = None
    publisher:str =None

class SearchAuthors(BaseModel):
    name:str = None
    awards:str = None

class SearchCategory(BaseModel):
    name:str = None
    description:str = None

class SearchReviews(BaseModel):
    contents:str =None
    rating:int = None

class SearchUsers(BaseModel):
    name:str = None
    email:str = None
    phone_number:str = None