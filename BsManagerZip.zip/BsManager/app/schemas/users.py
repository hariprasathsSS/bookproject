from pydantic import BaseModel, Field
from typing import Optional, List
from app.schemas import Idname
from datetime import datetime

class UserCreate(BaseModel):
    # created_at:datetime = Field(...,examples=['2024-07-01T15:40:30.960000'])
    # updated_at:datetime = Field(...,examples=['2024-07-01T15:40:30.960000'])
    name:str= Field(...,examples = ['udayreddy_26'])
    email:str = Field(..., examples = ["uday@zysec.ai"])
    gender:str = Field(..., examples= ['Male'])
    age:int = Field(...,examples=[29])
    phone_number:str =Field(...,examples=["+91-89654565"])
    favorite_books:list[Idname]
    total_reviews:int= Field(default=0,examples=[10])
    
class UserUpdate(BaseModel):
    
    name:Optional[str]= Field(None,examples = ['udayreddy_26'])
    email:Optional[str] = Field(None, examples = ["uday@zysec.ai"])
    gender:Optional[str] = Field(None, examples= ['Male'])
    age:Optional[int] = Field(None,examples=[29])
    phone_number:Optional[str] =Field(None,examples=["+91-89654565"])
    favorite_books:Optional[list[Idname]]=None
    total_reviews:Optional[int]= Field(None,examples=[10])

class UserResponse(BaseModel):

    id:str = Field(...,examples=["521h21g21fg1f56"])
    created_at:datetime = Field(...,examples=['2024-07-01T15:40:30.960000'])
    updated_at:datetime = Field(...,examples=['2024-07-01T15:40:30.960000'])
    name:str= Field(...,examples = ['udayreddy_26'])
    email:str = Field(..., examples = ["uday@zysec.ai"])
    gender:str = Field(..., examples= ['Male'])
    age:int = Field(...,examples=[29])
    phone_number:str =Field(...,examples=["+91-89654565"])
    favorite_books:list[Idname]
    total_reviews:int= Field(...,examples=[10])
    





