from pydantic import BaseModel, Field
from typing import Optional
from app.schemas import Idname
from app.models import Idname
from datetime import datetime

class BookCreate(BaseModel):
    # created_at:datetime=Field(...,default=0,examples=["01/02/2004: 00:00:00"])
    # updated_at:datetime=Field(...,examples=["01/02/2004: 00:00:00"])
    name: str=Field(...,examples=['IT'])
    description:str=Field(...,examples=['Thriller Incident on Beverly hills'])
    author: Idname
    is_published: bool=Field(...,examples=[True])
    publisher: Idname
    category: Idname
    average_rating: float=Field(default=0,examples=[5.5])
    total_reviews:int=Field(default=0,examples=[48])

class BookUpdate(BaseModel):
    # created_at:datetime=Field(...,default=0,examples=["01/02/2004: 00:00:00"])
    # updated_at:datetime=Field(...,examples=["01/02/2004: 00:00:00"])
    name: Optional[str]=Field(None,examples=['IT'])
    description:Optional[str]=Field(None,examples=['Thriller Incident on Beverly hills'])
    author: Optional[Idname]=None
    is_published: Optional[bool]=Field(None,examples=[True])
    publisher: Optional[Idname]=None
    category: Optional[Idname]=None
    # average_rating: Optional[float]=Field(default=0,examples=[5.5])
    # total_reviews:Optional[int]=Field(default=0,examples=[48])

class BookResponse(BaseModel):
    id:str=Field(...)
    created_at:datetime=Field(...,examples=["2024-07-02T12:57:42.076000"])
    updated_at:datetime=Field(...,examples=["2024-07-02T12:57:42.076000"])
    name: str=Field(...,examples=['IT'])
    description:str=Field(...,examples=['Thriller Incident on Beverly hills'])
    author: Idname
    is_published: bool=Field(...,examples=[True])
    publisher: Idname
    category: Idname
    average_rating: float=Field(...,examples=[5.5])
    total_reviews:int=Field(...,examples=[48])


