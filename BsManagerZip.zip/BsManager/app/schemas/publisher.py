from pydantic import BaseModel,Field
from typing import Optional
from app.schemas import Idname

class PublisherCreate(BaseModel):
    name:str = Field(...,examples=["Penguin Random House"])
    location:str = Field(...,examples=["New York, USA"])
    books:list[Idname]

class PublisherUpdate(BaseModel):
    name:Optional[str] = Field(None,examples=["Penguin Random House"])
    location:Optional[str] = Field(None,examples=["New York, USA"])
    books:Optional[list[Idname]]=None

class PublisherResponse(BaseModel):
    id:str = Field(...,examples=["88888t8t8t8t8t"])
    name:str = Field(...,examples=["Penguin Random House"])
    location:str = Field(...,examples=["New York, USA"])
    books:list[Idname]

