from pydantic import BaseModel,Field
from typing import Optional
from app.schemas import Idname

class CreateBookStore(BaseModel):
    name:str = Field(...,examples=["Barnes & Noble"])
    location:str = Field(...,examples=["New York, USA"])
    books: list[Idname]

class UpdateBookStore(BaseModel):
    name:Optional[str] = Field(None,examples=["Barnes & Noble"])
    location:Optional[str] = Field(None,examples=["New York, USA"])
    books: Optional[list[Idname]]=None

class ResponseBookStore(BaseModel):
    id:str = Field(...,examples=["9999aaa9999"])
    name:str = Field(...,examples=["Barnes & Noble"])
    location:str = Field(...,examples=["New York, USA"])
    books: list[Idname]