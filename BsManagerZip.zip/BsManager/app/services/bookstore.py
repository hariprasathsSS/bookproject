from app.services import BaseService
from app.models.bookstore import Bookstore
from app.schemas.bookstore import CreateBookStore,UpdateBookStore,ResponseBookStore

from bson import ObjectId
from fastapi import HTTPException,status
from motor.motor_asyncio import AsyncIOMotorDatabase


class BookStoreService(BaseService):
    def __init__(self, db:AsyncIOMotorDatabase):
        super().__init__(db)
        self.collection = db['BookStore']

    def normalizer(string:str)->str:
        return string.strip().lower() 
    async def CreateBookStore(self,bookstore: CreateBookStore):
        bkstr = (bookstore.model_dump())
        bkstr['location'] = bkstr['location'].strip().lower()
        res = await self.collection.insert_one(bkstr)
        bkstr = await self.collection.find_one({"_id":res.inserted_id})
        return self._to_response(bkstr,ResponseBookStore)
    async def getBookstoreDetails(self,bookstore_id:str):
        result = await self.collection.find_one({"_id":ObjectId(bookstore_id)})
        return self._to_response(result,ResponseBookStore)
    async def getBookStoreByLocation(self,bookstoreLocation:str):
        bookstoreLocation=bookstoreLocation.strip().lower()
        results = await self.collection.find({"location":bookstoreLocation}).to_list(None)
        return [self._to_response(result,ResponseBookStore) for result in results]
    
    async def getAllBookStore(self):
        bookstores = await self.collection.find().to_list(None)
        return [self._to_response(bstore,ResponseBookStore) for bstore in bookstores]

    async def deleteBookstore(self,bookstore_Id):
        res = await self.collection.delete_one({"_id":ObjectId(bookstore_Id)})
        if res.deleted_count == 0:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND)
    
    # async def addBookToBookStore(self,bookstore_id,book_id):


        
    