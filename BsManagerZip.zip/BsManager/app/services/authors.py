from app.services import BaseService
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from app.models.authors import Author
from app.schemas.authors import AuthorCreate,AuthorResponse,AuthorUpdate

from datetime import datetime,timezone

class AuthorService(BaseService):

    def __init__(self, db:AsyncIOMotorDatabase):
        super().__init__(db)
        self.collection=db['Authors']

    async def createAuthor(self,addAuthor:AuthorCreate):
       
        utcnow = datetime.now(timezone.utc)
        auth={**addAuthor.model_dump(),"created_at":utcnow,"updated_at":utcnow}
        res = await self.collection.insert_one(auth)
        auth = await self.collection.find_one({'_id':res.inserted_id})
        return self._to_response(auth,AuthorResponse)
    
    async def getAllAuthor(self):
        authors = await self.collection.find().to_list(None)
        return [self._to_response(auth,AuthorResponse) for auth in authors]
    
    async def getAuthor(self,auth_id):

        authors = await self.collection.find_one({"_id":ObjectId(auth_id)})
        return  self._to_response(authors,AuthorResponse)
    
    async def updateAuthor(self,auth_id:str,upAuthor:AuthorUpdate):
        res = await self.collection.update_one({'_id':ObjectId(auth_id)},
                                               {'$set':upAuthor.model_dump(exclude_unset=True)})
        uauth=await self.collection.find_one({'_id':ObjectId(auth_id)})
        return self._to_response(uauth,AuthorResponse)
    
    async def deleteAuthor(self,auth_id:str):
        res = await self.collection.delete_one({'_id':ObjectId(auth_id)})
    