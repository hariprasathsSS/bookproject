from app.schemas.books import BookResponse
from app.schemas.authors import AuthorResponse
from app.schemas.categories import CategoryResponse
from app.schemas.reviews import ReviewResponse
from app.schemas.users import UserResponse
from app.services import BaseService
from app.schemas.search import SearchBook

from motor.motor_asyncio import AsyncIOMotorDatabase

class Search(BaseService):
    def __init__(self, db:AsyncIOMotorDatabase):
        super().__init__(db)
        self.BookCollection = db['books']
        # self.AuthorCollection = db['']
        # self.BookCollection = db['books']
    async def searchBook(self,bookdata:SearchBook)