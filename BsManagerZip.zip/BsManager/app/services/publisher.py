from fastapi import status,HTTPException
from bson.errors import InvalidId
from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase
from app.services import BaseService
from app.schemas.publisher import PublisherCreate,PublisherResponse,PublisherUpdate
from app.models.publisher import Publisher

class PublisherService(BaseService):
    def __init__(self, db:AsyncIOMotorDatabase):
        super().__init__(db)
        self.collection=db['Publisher']
    
    async def addPublisher(self,publisherdata:PublisherCreate):
    
        publisher=publisherdata.model_dump()
        res = await self.collection.insert_one(publisher)
        publisher2= await self.collection.find_one({"_id":res.inserted_id})

        return self._to_response(publisher2,PublisherResponse)
    
    async def getAllPublishers(self):

        publishers = await self.collection.find().to_list(None)
        return [self._to_response(publisher,PublisherResponse)  for publisher in publishers]
    
    async def getPublisher(self,pub_id:str):

        publishers = await self.collection.find_one({"_id":ObjectId(pub_id)})
        return self._to_response(publishers,PublisherResponse)  
    
    async def updatePublisher(self,pub_id,upublisher:PublisherUpdate):

        publisher= upublisher.model_dump(exclude_unset=True)
        await self.collection.update_one({"_id":ObjectId(pub_id)},{'$set':publisher})
        publisher = await self.collection.find_one({"_id":ObjectId(pub_id)})
        return self._to_response(publisher,PublisherResponse)  
    async def deletePublisher(self,Pub_id):
        try:
            publisher = await self.collection.delete_one({"_id":ObjectId(Pub_id)})
            if publisher.deleted_count == 0:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="No data found")
        except InvalidId:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="Invalid ID")
        

    